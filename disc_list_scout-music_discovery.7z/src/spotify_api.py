"""
Module for Spotify API interactions
"""
