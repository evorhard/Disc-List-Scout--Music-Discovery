"""
Core application logic
"""
