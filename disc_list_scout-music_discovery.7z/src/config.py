"""
Configuration settings
"""
