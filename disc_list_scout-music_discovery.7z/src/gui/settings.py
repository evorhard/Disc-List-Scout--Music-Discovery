"""
Settings window
"""
